<?php

define('APP_ID','316140028482661');
define('APP_SECRET','452bfd0d7a69c651a3f99f62032d53fb');
//define('CALLBACK_URL',str_replace("getState", "callback", "http://".$_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]));

//ユーザー登録時のメールアドレス
define('MAIL','i@snghrym.com');


//FaceBookポスト時のフォーマットです。
//%title%: ポストする元Webページのタイトル
define('POST_FORMAT','『%title%』を読みました。');

?>