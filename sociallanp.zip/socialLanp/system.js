var dir = "socialLanp/system";
var cnt = "socialLanp/";
var label,mail;



$(document).ready(function(){

try{
	var socialLanpDoc = document.getElementById("js_socialLanp");
	var dLR = String(socialLanpDoc.src).split("?")[1];
}catch(e){
	//console.log(e);
}

	if(dLR!=undefined){
		cnt=dLR;
		dir=dLR+"/system";
		console.log("c");
	}

	$(".socialLanp").after('<div class="loadIcon" style="display:none;"><img src="'+dir+'/loadIcon.gif" /></div><div class="addContent"></div>');
	label = $(".socialLanp").attr('rel');
	checkLoginState();
    
});


//ログイン状態を取得する
function checkLoginState(){
	
	$.ajax({
		type: "POST",
		url: dir+"/getState.php",
		//async: false,
		success: function(getData){
			var loginUri = getData['loginUri'];
			var logoutUri = getData['logoutUri'];
			var loginState = getData['loginState'];
			mail = getData['mail'];
			//console.log("ログイン状態:"+loginState);
			//console.log(getData);
			//console.log("すでにシェアしている記事:"+getData['sharePost']);

			
			if(getData['auth']=="true"){
					$(".socialLanp").fadeIn();
					$(".loadIcon").slideUp();					
				$(".socialLanp").attr({href:loginUri});
			} //認証できていない場合はメッセージを表示して中断
			else{
				console.log("KEYファイルの内容が正常ではないため、確認します。");
				auth();
			}			
	
	/*
				if(loginState>0){ //すでにログインしている場合
					//open(getData['name']);	//『続き』を表示する
					console.log("ログインしています");
				}else{
					$(".socialLanp").fadeIn();
					$(".loadIcon").slideUp();					
				}
*/

			}
	});	
	
}



function debug(){
	//$("#debug").append("start debug mode");

	$.ajax({
		type: "POST",
		url: dir+"/getState.php",
		//async: false,
		success: function(getData){
			console.log(getData);
			}
	});	
	
}

function callback(name){
	console.log("cb:"+name);
	open(name);
}



//記事を開く
function open(name){
	if(auth() == "false"){
		console.log("メールアドレスの値が正しくありません");
		return false;
	} //認証できていない場合はメッセージを表示して中断
	
	$("div.loadIcon").slideDown();
	$(".socialLanp").fadeOut();

			$.ajax({
				type: "POST",
				//async: false,
				//data:dir+'/content/'+name,
				url: cnt+"/content/"+label+'.php',
				success: function(data){
					if(data!=""){ //何かしらのコンテンツが取得できた場合
						$(".addContent").append(data);
						$(".addContent").slideDown();
	
						share();
						//debug();
						$("div.loadIcon").slideUp();
					}
					else{ //何も取得できなかった場合
					console.log("ERROR:"+data);
						$(".addContent").text("続きの読み込みに失敗しました。");
						//$(".socialLanp").fadeOut();
						//$(".addContent").slideDown();
						$("div.loadIcon").slideUp();					
					}
					
				},
				error: function(data){
						console.log("ERROR:"+data);
						$(".addContent").text("続きの読み込みに失敗しました。");
						$(".socialLanp").fadeOut();
						$(".addContent").fadeIn();
						$("div.loadIcon").slideUp();					
				}
			});
		

}


function share(){
		if(checkShare()){//記事をシェアする必要があるかどうかを判断する
			$.ajax({
				type: "POST",
				url: dir+"/share.php",
				//data: "postSlug="+postSlug,
				//async: false,
				data: "title="+document.title+"&url="+document.URL,
				success: function(data){
					console.log(data);
				}
			});			
		}else{
			console.log("FaceBookでのポストは行いませんでした。");
		}
}

function logout(){
	$.ajax({
		type: "POST",
		url: dir+"/logout.php",
		success: function(data){
			console.log(data);
			checkLoginState();
			$(".addContent").slideUp();
			$(".addContent").html("");
		}
	});
}



//記事をポストするかどうかを判断する
//シェアしておらず、シェアする必要がある場合はtrue、シェアする必要が無い場合はfalse
function checkShare(){
	var checkBool = false;
		$.ajax({
		type: "POST",
		async: false,
		url: dir+"/getState.php",
		success: function(getdata){
				var i = getdata['shareInfo'];
				//console.log("checkShare-shareInfo:"+i);
				if(i!='already') //『すでにシェアしている』ではない場合
					checkBool = true;
				else
				 	checkBool = false;
			},
		error: function(getData){
			checkBool = false;
		}
	});			
	return checkBool;
}




//config.phpのメールアドレスの値が正しいかどうかを判定する
function auth(){
	var checkBool = false;
	$.ajax({
		type: "POST",
		async: false,
		data: "mail="+mail,
		url: "http://sociallanp.lastlanp.jp/plugin/auth.php",
		success: function(getdata){
			checkBool = getdata;
			//console.log(getdata);
			
				//Keyファイルを作成する
				$.ajax({
					type: "POST",
					url: dir+"/keygen.php",
					success: function(getdata){
						//console.log(getdata);
						},
					error: function(getdata){
						console.log(getdata);
					}
				});			
			
			},
		error: function(getdata){
			checkBool = getdata;
			console.log(getdata);
		}
	});			
	return checkBool;
}



//送信ボタンを押した時の処理
/*
function submit(){
	var mail = $(".dlForm input#mail").val();
	var name = $(".dlForm input#name").val();
	console.log(mail+name);

		$.ajax({
		type: "POST",
		//async: false,
		data: "name="+name+"&mail="+mail,
		url: dir+"/submit.php",
		success: function(getData){
			if(getData){
				sendExpert(getData);
				console.log("suc:"+getData);
			}
			else
				console.log("失敗です。");
			},
		error: function(getData){
			console.log(getData);
		}
	});			

}


//データベースに接続し終わり、エキスパートメールの送信ボタンを押したことにする処理
/*
function sendExpert(auth){
	console.log("sendExpert");
	
	$("#auth").val(auth);
	$(".dlForm .send").click();

}
*/






