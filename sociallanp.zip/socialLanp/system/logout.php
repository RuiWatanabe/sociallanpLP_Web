<?php
	session_start();
	require 'sdk/facebook.php';

	require '../../../wp-load.php';
	$facebook = new Facebook(array(
	    'appId' => get_option('sharePost_AppId'),
	    'secret' => get_option('sharePost_AppSecret')
	));

	$facebook->destroySession();
	$_SESSION['sharePost'] = array();
?>