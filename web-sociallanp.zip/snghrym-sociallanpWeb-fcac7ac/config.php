<?php

//Facebookのアプリ情報
define('APP_ID','***************');
define('APP_SECRET','*******************************');

//ユーザー登録時のメールアドレス
//define('MAIL','hirayamaru@gmail.com');



//FaceBookポスト時の内容を指定することができます。
define('POST_FORMAT','『%title%』にログインしました。');
//%title%: ポストする元Webページのタイトル


//セーフモード
define('SAFEMODE',FALSE);
//TRUEになっている場合、ログインを行なってもFacebookに投稿されません。

//追加コンテンツを事前に読み込んでおくかどうかを指定します。
define('PRIOR',FALSE);
//TRUEにすると、ボタンクリック後の読み込みが早くなります。
//FALSEにすると、追加コンテンツが不正に取得される危険性が低くなります。

//追加コンテンツに対してアクセストークン情報を送信するかどうか
define('SEND_TOKEN',TRUE);
//追加先のコンテンツで、認証したFacebook情報を利用する場合などに、TRUEにします。


?>