<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

    <meta property="og:title" content="革新的！口コミ拡散ツール【SocialLanp：ソーシャルランプ】の無料ダウンロードはこちら" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="http://sociallanp.lastlanp.jp/" />
    <meta property="og:image" content="http://sociallanp.lastlanp.jp/image/ogp.png" />
    <meta property="og:site_name" content="SocialLanp -ソーシャルランプ- | 日本が世界で戦うために製造された、究極のマーケティングシステム" />

	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>ソーシャルランプ: 設定テストページ</title>

	<!-- 同じディレクトリ内で呼び出す場合 -->
	<script class="sociallanp" type="text/javascript" src="system.js"></script>
	
	<!-- 異なったディレクトリから呼び出す場合 
	<script class="sociallanp" type="text/javascript" src="http://hirayamaru.info/sociallanp"></script>
	-->


<style type="text/css">

	body{
		margin:0;
	}

	.wrapper{
		margin-right: auto;
		margin-left: auto;
		width:90%;
		height:100%;
		text-align: center;
	}
	
	.sociallanp{
		display: block;
		width:302px;
		height:64px;
		background-image: url("system/images/button_off.png");
		
		color: #fff;
		font-size: 16px;
		text-decoration: none;
		font-weight: bold;
		line-height: 62px;
		letter-spacing: .2em;
		
		margin-right: auto;
		margin-left: auto;
	}
	
	.socialLanp:hover{
		background-image: url("system/images/button_on.png");		
	}
	
	.addContent{
		text-align: left;
	}
</style>

</head>


<body>

<div class="wrapper">
	<h1>今すぐシェアしてクーポンをゲット！</h1>
	<p>↓ボタン内のテキストは自由に変更できます！</p>
	<a class="sociallanp" rel="test" target="_blank">Facebookで認証後 続きを読む！</a>
</div>

</body>
</html>
