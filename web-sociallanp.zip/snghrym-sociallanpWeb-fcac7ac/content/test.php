<?php


//header("Location: http://snghrym.com/wp-admin/options-general.php?page=wp-sociallanp/socialLanp.php");
require '../config.php';
require '../system/sdk/facebook.php';

$facebook = new Facebook(array(
    'appId' => APP_ID,
    'secret' => APP_SECRET
));
	
?>
<h2>Facebookへのログインに成功しました。</h2>

<p>取得した情報</p>
<pre>
<?php
$facebook->setAccessToken($_REQUEST['token']); //ログインしているかどうかをチェック。している場合ユーザIDを返す。
$u = $facebook->api("/me&locale=ja_JP");
print_r($_REQUEST);
print_r($u);
?>
</pre>

<img src="<?php echo $_REQUEST['dirSystem']; ?>/images/icon.png" />

<p>初期設定のままでは、実際のシェアは行われません。</p>
<p>Facebookへポストしたい場合は、[config.php]の SAFEMODE を FALSE に設定してください。</p>