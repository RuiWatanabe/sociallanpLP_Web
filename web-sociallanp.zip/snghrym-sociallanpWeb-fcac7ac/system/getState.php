<?php
session_start();
require '../config.php';
require 'sdk/facebook.php';
$facebook = new Facebook(array(
		'appId' => APP_ID,
		'secret' => APP_SECRET
));
$error = "";
$loginState = $facebook->getUser();
define('CALLBACK_URL', str_replace("getState", "callback", "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]));
$params = array(
		'scope' => 'publish_stream,email',
		'redirect_uri' => CALLBACK_URL
);
$loginUrl = $facebook->getLoginUrl($params);
$logoutUrl = $facebook->getLogoutUrl();
if ($loginState)
{
		$token = $facebook->getAccessToken();
} //$loginState
else
{
		$error = "ログインできていません。$error";
}
$info = array(
		'prior' => PRIOR,
		'callBackUrl' => CALLBACK_URL,
		'loginState' => $loginState,
		'loginUri' => $loginUrl,
		'logoutUri' => $logoutUrl,
		'error' => $error,
		'nowpage' => "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]
);
header('Content-type: application/json');
echo json_encode($info);
?>