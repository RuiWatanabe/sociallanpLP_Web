<?php

require '../config.php';
require 'sdk/facebook.php';

//$url = $_REQUEST['url'];


$facebook = new Facebook(array(
		'appId' => APP_ID,
		'secret' => APP_SECRET
));


try {
		$facebook->setAccessToken($_REQUEST['token']); //ログインしているかどうかをチェック。している場合ユーザIDを返す。
		$login = $facebook->getAccessToken();
}
catch (Exception $e) {
		$return = "false : アクセストークンを取得できませんでした。";
}


if ($login) {
		try {
				$postdata = str_replace("%title%", $_REQUEST['title'], POST_FORMAT); //%title%→サイトのタイトル
				
				
				if (!SAFEMODE) {
						try {
								$facebook->api('/me/feed', 'POST', array(
										'message' => $postdata,
										'link' => $_REQUEST['url']
								));
								$return = "true : FaceBookにポストしました。";
						}
						catch (Exception $e) {
								$return = "false : ポストに失敗しました。";
						}
						
				} //!SAFEMODE
				else {
						$return = "true : セーフモードになっているため、ポストしませんでした。";
				}
				
				
		}
		catch (Exception $e) {
				$return = $return . " : 送信情報を設定できませんでした。";
		}
		
		
		try {
				if (SEND_TOKEN)
						$token = $login;
		}
		catch (Exception $e) {
				$return = $return . " : トークンを取得できませんでした。";
		}
} //$login
else {
		$return = $return . " : ログインできていません" . $login;
}

echo $return;
?>